<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>config mail</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>
<body>
<form id="commentForm" method="post" action="contact.php">
        <input type="hidden" name="emailTo" value="info@revealangkor.com"/>
        <input type="hidden" name="info" value="Banteay Chhas Village, Slokram Commune, Siem Reap, Cambodia"/>
        <input type="hidden" name="images" value="images/reveal-angkor-logo.png"/>
        <input type="hidden" name="rooturl" value="http://www.revealangkor.com"/>
        <input id="check" type="hidden" name="check" value="" tabindex="-1" autocomplete="nope">
        
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>First Name *</label>
                <input type="text" class="form-control i-user input-style" id="firstname" name="txt_firstname" placeholder="your first name" required> 
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Last Name *</label>
                <input type="text" class="form-control i-user input-style" id="lastname" name="txt_lastname" placeholder="your last name" required> 
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Email *</label>
                <input type="text" class="form-control i-email input-style" id="email" name="txt_email" placeholder="email" required> 
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Phone</label>
                <input type="text" class="form-control i-phone input-style" id="phone" name="txt_phoneNumber" placeholder="your phone number"> 
                </div>
            </div>
        </div>
        <div class="form-group">
            <label>Messages</label>
        <textarea type="text" class="form-control i-msg" id="message" name="txt_message" placeholder="text message here..." rows="5"></textarea>
        </div>
        <span style='height: 20px; display: block; clear: both;'></span>
        <div class="g-recaptcha" data-sitekey="6LcKxJwUAAAAABU4FXqBcg3bGG8j9qhVxDzXv_te"></div>
        <span style='height: 30px; display: block; clear: both;'></span>
        <div class="text-center">
            
        <div id="chatbox"></div>
        <button id="submitContact090219" type="submit" name="submit" class="btn-detail">Send Message <i class="fas fa-spin spin-contact"></i></button>
        </div>
        <span style='height: 20px; display: block; clear: both;'></span>
    </form>

<script src='https://www.google.com/recaptcha/api.js'></script>
</body>
</html>

<!-- =====================================phpsendmail============================================================= -->
<?php
include('SMTP.php');

$url = 'https://www.google.com/recaptcha/api/siteverify';
$data = array(
  'secret' => '6LcKxJwUAAAAAESnHSB9JZ_fb9ZUU_66fGG2zCre',
  'response' => $_POST["g-recaptcha-response"]
);
$query = http_build_query($data);
$options = array(
    'http' => array(
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n".
                    "Content-Length: ".strlen($query)."\r\n".
                    "User-Agent:MyAgent/1.0\r\n",
        'method'  => "POST",
        'content' => $query,
    ),
);

$context  = stream_context_create($options);
$verify = file_get_contents($url, false, $context);
$captcha_success=json_decode($verify);

if ($captcha_success->success==false) {
  echo json_encode(array('status'=>false, 'message' => "<span style='color:red;'>Please check I'm not a robot. </span>"));
  exit;

  echo "<p style='font-family: arial;font-size: 22px;text-align: center;padding: 30px;background: #eee;position: absolute;color: #3e3e3e;top: 40%;left: 50%;-webkit-transform: translate(-50%,-50%);transform: translate(-50%,-50%);'>
  Please verifty that you are not a robot. <br><br> Please go <a href='javascript:history.go(-1)'>back</a> and try again.</p>";

} else if ($captcha_success->success==true) {


    date_default_timezone_set('Asia/Phnom_Penh');
    require "phpmailer/PHPMailerAutoload.php";
    $mail = new PHPMailer(true);
    

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = $smtp_host;                             // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = $smtp_username;                     // SMTP username
    $mail->Password = $smtp_password;                     // SMTP password
    $mail->SMTPSecure = "ssl";                            // Enable TLS encryption, ssl also accepted
    $mail->Port = 465;                                    // TCP port to connect to
    

    $firstname   = $_POST['txt_firstname'];
    $lastname   = $_POST['txt_lastname'];
    $email      = $_POST['txt_email'];
    $phone      = $_POST['txt_phoneNumber'];
    $msg        = $_POST['txt_message'];
 

    //Get Image from CMS
    $emailto    =$_POST['emailTo'];
    $root_url   =$_POST['rooturl'];
    $image      =$_POST['images'];
    $info       =$_POST['info'];
    $date1      =date("Y-m-d H:m:s a");
    

    $HTML ="
    <table style='padding: 0px; width: 100%; min-width: 675px; border: 1px solid #ccc; font-family: arial; font-size: 12px;border-collapse: collapse;'>
    <tbody>
    <!— Header and Get logo images —>
    <tr style='background: #000;'><td style='border-bottom: 1px solid #ddd;padding:10px 25px;'>
        <a href='$root_url' target='_blank'><img width='70' src='$root_url/uploads/$image'></a>
    </td></tr>
    <!— Content detail about book and contact —>
    <tr style='text-align: left; '><td style='border-bottom: 1px solid #ddd;padding: 15px 20px;'>
      <table width='100%' border='0' style='font-family: arial;font-size: 12px;'>
      <tbody>
      <tr style='height: 50px;'>
        <td style='font-family: arial;font-size: 22px;width: 100%;' colspan='2'><strong>Contact</strong><br/></td>
      </tr>
      <tr>
        <td style='width: 200px;'>First Name</td>
        <td style='width: 800px;'>: $firstname</td>
      </tr>
      <tr>
        <td style='width: 200px;'>Last Name</td>
        <td style='width: 800px;'>: $lastname</td>
      </tr>
      <tr>
        <td style='width: 200px;'>Email</td>
        <td style='width: 800px;'>: $email</td>
      </tr>
      <tr>
        <td style='width: 200px;'>Phone</td>
        <td style='width: 800px;'>: $phone</td>
      </tr>
      <tr>
        <td style='width: 200px;'>Messages</td>
        <td style='width: 800px;'>: $msg</td>
      </tr>
      </tbody>
      </table>
    </td></tr>
    <!— Footer —>
    <tr style='text-align: left;'><td style='padding: 20px;'>
        <p>Inquery Date:  $date1</p>
    </td></tr>
    </tbody>
    </table>
    ";


    $subject = "Contact | Reveal Angkor Hotel";
    $mail->setFrom($smtp_username, $firstname." ".$lastname);
    $mail->addReplyTo($email, $firstname." ".$lastname);
    $mail->addAddress($emailto, "Contact | Reveal Angkor Hotel");   // Add a recipient
    $mail->addBcc("info@esoftix.com", "eSoftix");
    $mail->isHTML(true);   // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $HTML;
    

    if(!$mail->send()) {
      echo "Message could not be sent1.";
      echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
      

      //echo "Message can be sent1.";
      // Auto Respond
      $mail = new PHPMailer;
      $mail->isSMTP();                    // Set mailer to use SMTP
      $mail->Host = $smtp_host;           // Specify main and backup SMTP servers
      $mail->SMTPAuth = true;             // Enable SMTP authentication
      $mail->Username = $smtp_username;   // SMTP username
      $mail->Password = $smtp_password;   // SMTP password
      $mail->SMTPSecure = "ssl";          // Enable TLS encryption, ssl also accepted
      $mail->Port = 465;                  // TCP port to connect to
      

      $HTML = "
      <br/>
      <p style='font-size12px;'>Dear $firstname,<p/>
      <p style='font-size12px;'>This is an automatic message sent by our website to view your information that you have sent to us.</p><br/>

      <table style='padding: 0px; width: 100%; min-width: 675px; border: 1px solid #ccc; font-family: arial; font-size: 12px;border-collapse: collapse;'>
        <tbody>
        <!— Header and Get logo images —>
        <tr style='background: #000;'><td style='border-bottom: 1px solid #ddd;padding:10px 25px;'>
            <a href='$root_url' target='_blank'><img width='70' src='$root_url/uploads/$image'></a>
        </td></tr>
        <!— Content detail about book and contact —>
        <tr style='text-align: left; '><td style='border-bottom: 1px solid #ddd;padding: 15px 20px;'>
          <table width='100%' border='0' style='font-family: arial;font-size: 12px;'>
          <tbody>
          <tr style='height: 50px;'>
            <td style='font-family: arial;font-size: 22px;width: 100%;' colspan='2'><strong>Contact</strong><br/></td>
          </tr>
          <tr>
            <td style='width: 200px;'>First Name</td>
            <td style='width: 800px;'>: $firstname</td>
          </tr>
          <tr>
            <td style='width: 200px;'>Last Name</td>
            <td style='width: 800px;'>: $lastname</td>
          </tr>
          <tr>
            <td style='width: 200px;'>Email</td>
            <td style='width: 800px;'>: $email</td>
          </tr>
          <tr>
            <td style='width: 200px;'>Phone</td>
            <td style='width: 800px;'>: $phone</td>
          </tr>
          <tr>
            <td style='width: 200px;'>Messages</td>
            <td style='width: 800px;'>: $msg</td>
          </tr>
          </tbody>
          </table>
          <br /><br />
          <p>We'll manually review your message and reply you as soon as possible.</p>
          <p>Best Regards,</p>
          <strong>Reveal Angkor Hotel</strong><br>
        </td></tr>
        <!— Footer —>
        <tr style='text-align: left;'>
        <td style='padding: 20px;'>
            <p>Inquery Date:  $date1</p>
            <p>$info</p>
        </td></tr>
        </tbody>
      </table>
      ";


      $mail->setFrom($smtp_username,  "Contact | Reveal Angkor Hotel");
      $mail->addAddress($email, $firstname." ".$lastname);     // Add a recipient
      $mail->addReplyTo("info@revealangkor.com", "Reveal Angkor Hotel");
      $mail->isHTML(true);// Set email format to HTML
      $mail->Subject = "Your information has been submitted successfully";
      $mail->Body    = $HTML;
      

      if(!$mail->send()) {
        echo "Message could not be sent2.";
        echo "Mailer Error: " . $mail->ErrorInfo;
      } else {
        //echo "Message has been sent2<br />";
        echo json_encode(array('status'=>true, 'message' => "<span style='color:green;'>Your email was sent successfully.</span>"));
      }
        

    }// End cussess To
    

}//End Captcha



// RESET Recaptcha
grecaptcha.reset();

// RESET recaptcha
document.getElementById("commentForm").reset();

/*==================================current node==============================*/
{assign http "http://{$smarty.server.HTTP_HOST}{$smarty.server.REQUEST_URI}"}