<?php
// Variable Get From Default Contact Form

$secret_key = $_POST["secretkey"];
$emailto = $_POST["email_to"];
$emailcc  = $_POST['email_cc'];
$sitename = $_POST['sitename'];
$root_url  = $_POST['root_url'];
$address    = $_POST['address'];
$logo_white  = $_POST['logo_img_white'];

// Variable Mailer
$title      = $_POST['Subject_Mail'];
$color    = $_POST['color_code'];
$fullname   = $_POST['name'];
$email      = $_POST['email'];
$msg        =  $_POST['message'];

$date = date('l, F d, Y - h:i:s a');
// ==========================================
include("SMTP.php");
$url = 'https://www.google.com/recaptcha/api/siteverify';
$data = array(
  'secret' => $secret_key,
  'response' => $_POST["g-recaptcha-response"]
);
$query = http_build_query($data);

$options = array(
    'http' => array(
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n".
                    "Content-Length: ".strlen($query)."\r\n".
                    "User-Agent:MyAgent/1.0\r\n",
        'method'  => "POST",
        'content' => $query
    ),
);

$context  = stream_context_create($options);
$verify = file_get_contents($url, false, $context);
$captcha_success=json_decode($verify);


date_default_timezone_set('Asia/Phnom_Penh');
require 'phpmailer/PHPMailerAutoload.php';
$mail = new PHPMailer;

//Get Data 
 
// $date = date("Y-m-d H:m:s a");

// Owner Mail
$HTML="
<div style='margin: auto; max-width: 750px;'>
  <table style='width: 100%; border-collapse: collapse; border: 1px solid rgb(61, 61, 61); font-size: 14px;'>
      <thead style='background-color: $color;'>
          <tr>
              <td style='text-align: center;' colspan='2'>
                  <a href='$root_url' target='_blank'>
                      <img src='' height='80px'>
                  </a>
              </td>
          </tr>
      </thead>
      <tbody style='vertical-align: text-top; line-height: 25px;'>
          <tr>
              <td colspan='2' style='height: 1rem;'></td>
          </tr>
          <tr>
              <td colspan='2' style='padding: 10px 20px; font-weight: 700; font-size: 20px; color: $color;'>$title</td>
          </tr>
          <tr>
              <td colspan='2' style='height: 1rem;'></td>
          </tr>

<!--    Field Data Mailler     -->

          <tr>
              <td style='padding: 10px 20px;' width='150px'>Name</td>
              <td style='padding: 10px 20px;'>$fullname</td>
          </tr>
          <tr>
              <td style='padding: 10px 20px;' width='150px'>Email</td>
              <td style='padding: 10px 20px;'>$email</td>
          </tr>
          <tr>
              <td style='padding: 10px 20px;' width='150px'>Message</td>
              <td style='padding: 10px 20px;'>$msg</td>
          </tr>

<!--    Field Data Mailler     -->

      </tbody>
  </table>
</div>
";

$mail->IsSMTP();                                     // Set mailer to use SMTP
$mail->Host = $smtp_host;           // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = $smtp_username;                 // SMTP username
$mail->Password = $smtp_password;                           // SMTP password
$mail->SMTPSecure = 'ssl';                             // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465; 

$mail->setFrom($smtp_username);
$mail->addAddress($emailto);   
$mail->addReplyTo($email);  	  // Add a recipient
$mail->addBCC("webdev@esoftix.com");
$mail->addCC($emailcc);

$mail->isHTML(true); // Set email format to HTML

$mail->Subject = 'Inquiry from '.$sitename;
$mail->Body    = $HTML;
if(!$mail->send()) {
  echo "Message could not be sent1.";
  echo "Mailer Error: " . $mail->ErrorInfo;
}else{

  // Auto Respond // Customer
  $mail = new PHPMailer;
  $HTML = "
  <div style='margin: auto; max-width: 750px;'>
    <p>Dear <b>$fullname</b></p>
    <p>This is an automatic message sent by our website to view your information that you have sent to us.</p>
    <table style='width: 100%; border-collapse: collapse; border: 1px solid rgb(61, 61, 61); font-size: 14px;'>
        <thead style='background-color: $color;'>
            <tr>
                <td style='text-align: center;' colspan='2'>
                    <a href='$root_url' target='_blank'>
                        <img src='$logo_white' height='80px'>
                    </a>
                </td>
            </tr>
        </thead>
        <tbody style='vertical-align: text-top; line-height: 25px;'>
            <tr>
                <td colspan='2' style='height: 1rem;'></td>
            </tr>
            <tr>
                <td colspan='2' style='padding: 10px 20px; font-weight: 700; font-size: 20px; color: $color;'>$title</td>
            </tr>
            <tr>
                <td colspan='2' style='height: 1rem;'></td>
            </tr>

<!--    Field Data Mailler     -->

            <tr>
                <td style='padding: 10px 20px;' width='150px'>Name</td>
                <td style='padding: 10px 20px;'>$fullname</td>
            </tr>
            <tr>
                <td style='padding: 10px 20px;' width='150px'>Email</td>
                <td style='padding: 10px 20px;'>$email</td>
            </tr>
            <tr>
                <td style='padding: 10px 20px;' width='150px'>Message</td>
                <td style='padding: 10px 20px;'>$msg</td>
            </tr>

<!--    Field Data Mailler     -->

        </tbody>
        <tfoot style='vertical-align: text-top; line-height: 25px; color: $color;'>
            <tr>
                <td colspan='2' style='height: 2rem;'></td>
            </tr>
            <tr>
                <td style='padding: 5px 20px;' colspan='2'>We'll manually review your message and reply you as soon as possible.</td>
            </tr>
            <tr>
                <td style='padding: 5px 20px;' colspan='2'>Best Regards,</td>
            </tr>
            <tr>
                <td style='padding: 5px 20px; font-weight: 700; font-size: 16px;' colspan='2'>$sitename</td>
            </tr>
            <tr>
                <td colspan='2' style='height: 2rem;'></td>
            </tr>
        </tfoot>
    </table>
    <footer style=' font-size: 14px;'>
        <p>Inquiry Date : $date</p>
        <p>Address : $address</p>
    </footer>
  </div>
";
  $mail->IsSMTP();                                     // Set mailer to use SMTP
  $mail->Host = $smtp_host;           // Specify main and backup SMTP servers
  $mail->SMTPAuth = true;                               // Enable SMTP authentication
  $mail->Username = $smtp_username;                 // SMTP username
  $mail->Password = $smtp_password;                            // SMTP password
  $mail->SMTPSecure = 'ssl';                             // Enable TLS encryption, `ssl` also accepted
  $mail->Port = 465;

  $mail->setFrom($smtp_username);
  $mail->addAddress($email);    // Add a recipient
  $mail->addReplyTo($emailto);


  $mail->isHTML(true);                                  // Set email format to HTML

  $mail->Subject = 'Your Inquiry';
  $mail->Body    = $HTML;

    if(!$mail->Send()) {
      echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
      header("Location: thank-you.html");
    }
  }

?>