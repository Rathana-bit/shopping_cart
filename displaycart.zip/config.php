<?php
# CMS Made Simple Configuration File

$config['dbms'] = 'mysqli';
$config['db_hostname'] = 'localhost';
$config['db_username'] = 'root';
$config['db_password'] = 'admin@rathana';
$config['db_name'] = 'db_newsimplecart';
$config['db_prefix'] = 'cms_';
$config['timezone'] = 'Asia/Phnom_Penh';
$config['query_var'] = 'page';
$config['url_rewriting'] = 'mod_rewrite';
$config['page_extension'] = '.html';
$config['use_hierarchy'] = true;
$config['root_url'] = 'http://localhost:8899/newsimplecart.com';


?>